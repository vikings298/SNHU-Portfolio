# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, password): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = username 
        PASS = password
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
    #This method obtains the next available record number by first sorting in descending order
    #by record number, and using find_one to grab the first item, which is the highest record number. 
    #We then add one to that number and return it, or return 1 if result is empty. 
    def getNextRecordNumber(self):
      result = self.collection.find_one(sort=[("rec_num", -1)])
      if result is not None:
        return result["rec_num"] + 1
      else:
        return 1
            
    # Complete this create method to implement the C in CRUD. 
    #This method inserts a document given a key/value pair (data). 
    #Uses a new record number obtained from getNextRecordNumber() function. 
    #Will return true if data is not none and insert is successful, and false otherwise. 
    def create(self, data):
        if data is not None:
          data["rec_num"] = self.getNextRecordNumber()
          self.collection.insert_one(data)  # data should be dictionary   
          return True      
        else: 
            return False 
            

    # Create method to implement the R in CRUD.
    def read(self, data):
      #This method returns a list of results given a key/value pair (data).
      #Returns an empty list if data is empty. 
      #Converts the cursor object returned by MongoDB, then converts it into a list. 
      
      if data is not None:
        cursorObject = self.collection.find(data)
        return list(cursorObject)
      
      else:
        return []

    #Update method to implement U in CRUD
    #This method takes a dictionary query, and a dictionary of info to be updated. 
    #It returns the number of objects modified 
    def update(self, query, data):

      if query is not None and data is not None:

        result = self.collection.update_many(query, {"$set": data})

        return result.modified_count

      else:
        return 0

    #Delete method to implement D in CRUD
    #This method takes a dictionary query, and performs delete on matching objects. 
    #Returns the number of objects deleted. 
    def delete(self, query):

      if query is not None:

        result = self.collection.delete_many(query)

        return result.deleted_count
      
      else:
        return 0